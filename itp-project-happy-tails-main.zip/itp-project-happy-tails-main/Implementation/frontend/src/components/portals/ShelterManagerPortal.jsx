import React from "react";

function ShelterManagerPortal() {
  return <h1 className="text-4xl text-center">ShelterManagerPortal</h1>;
}

export default ShelterManagerPortal;
