import React from "react";

function EventManagerPortal() {
  return <h1 className="text-4xl text-center">EventManagerPortal</h1>;
}

export default EventManagerPortal;
